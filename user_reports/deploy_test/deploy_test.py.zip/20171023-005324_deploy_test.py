

import string
import random
import json

def report(aresObj):
  
  return aresObj