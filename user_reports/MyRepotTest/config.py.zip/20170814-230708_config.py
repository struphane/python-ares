""" Global Configuration for Ares

"""

ARES_FOLDER = 'ares'
ARES_USERS_LOCATION = 'user_reports'
ARES_USERS_DELETED_FOLDERS = 'user_deleted_reports'