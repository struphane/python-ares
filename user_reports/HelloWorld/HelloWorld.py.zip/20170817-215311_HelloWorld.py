''' [SCRIPT COMMENT] 

 >>>> Important variables 
In the python layer 
   aresObj.http['FILE'] is the current file 
   aresObj.http['REPORT_NAME'] is the current report environment name 

In the javascript layer 
   display(data) to return the result in a notification modal popup 
   preloader() to show a loading page 

AJAX_CALL = {} # Ajax call definition 
CHILD_PAGES = {} # Child pages call definition e.g {'test': 'MyRepotTestChild.py',} 

def report(aresObj):



  return aresObj